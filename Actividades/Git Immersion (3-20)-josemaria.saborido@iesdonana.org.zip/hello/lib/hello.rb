# Default is World
# Author: José María Saborido (josemaria.saborido@iesdonana.org)
name = ARGV.first || "World"

puts "Hello, #{name}!"